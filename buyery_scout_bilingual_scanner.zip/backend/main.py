"""Optional private eBay Browse API proxy. Never expose credentials to browser."""
import os,time
import requests
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
app=FastAPI(title='Buyery Scout private API')
origins=[x.strip() for x in os.getenv('SCOUT_ALLOWED_ORIGINS','').split(',') if x.strip()]
app.add_middleware(CORSMiddleware,allow_origins=origins,allow_methods=['GET'],allow_headers=['*'])
token_cache={'token':None,'expires':0}
def token():
    if token_cache['token'] and token_cache['expires']>time.time()+60:return token_cache['token']
    cid=os.getenv('EBAY_CLIENT_ID');secret=os.getenv('EBAY_CLIENT_SECRET')
    if not cid or not secret:raise HTTPException(503,'eBay Production credentials not configured')
    r=requests.post('https://api.ebay.com/identity/v1/oauth2/token',auth=(cid,secret),data={'grant_type':'client_credentials','scope':'https://api.ebay.com/oauth/api_scope'},timeout=12)
    if not r.ok:raise HTTPException(502,'eBay authentication failed')
    data=r.json();token_cache.update(token=data['access_token'],expires=time.time()+data.get('expires_in',7000));return token_cache['token']
@app.get('/health')
def health():return {'ok':True,'marketplace':'EBAY_GB','sold_data':'not provided'}
@app.get('/search')
def search(q:str):
    q=q.strip()
    if not 3<=len(q)<=120:raise HTTPException(400,'Query must contain 3–120 characters')
    r=requests.get('https://api.ebay.com/buy/browse/v1/item_summary/search',headers={'Authorization':'Bearer '+token(),'X-EBAY-C-MARKETPLACE-ID':'EBAY_GB'},params={'q':q,'limit':15,'filter':'buyingOptions:{FIXED_PRICE}'},timeout=12)
    if not r.ok:raise HTTPException(502,'eBay active listing lookup failed')
    items=[]
    for i in r.json().get('itemSummaries',[]):
        p=i.get('price',{})
        if p.get('currency')=='GBP':items.append({'title':i.get('title',''),'price':float(p.get('value',0)),'url':i.get('itemWebUrl','')})
    return {'items':items,'source':'eBay Browse API','type':'active asking prices','sold_data':None}
